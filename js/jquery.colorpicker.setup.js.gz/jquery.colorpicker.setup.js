jQuery(function($){
	$('input[type="color"]').wpColorPicker();
});