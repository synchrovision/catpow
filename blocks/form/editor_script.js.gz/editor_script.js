(() => {
  // ../blocks/form/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/form", {
    icon: "editor-code",
    category: "catpow-embed",
    example: CP.example,
    edit({ attributes, setAttributes, className }) {
      const { content_path, post_data_path, inputs, data_id, values } = attributes;
      const { InspectorControls, useBlockProps } = wp.blockEditor;
      const { PanelBody, TreeSelect, TextareaControl, TextControl } = wp.components;
      const { serverSideRender: ServerSideRender } = wp;
      let postDataSelection = false;
      Object.keys(cpEmbeddablesTree.form).forEach((parentKey) => {
        cpEmbeddablesTree.form[parentKey].children.map((item) => {
          if (item.id === content_path && item.post_data_paths) {
            postDataSelection = [];
            Object.keys(item.post_data_paths).forEach(function(key) {
              postDataSelection.push({
                id: key,
                name: item.post_data_paths[key]
              });
            });
          }
        });
      });
      if (postDataSelection === false) {
        if (post_data_path) {
          setAttributes({ post_data_path: false });
        }
      } else {
        if (!post_data_path || !postDataSelection.some((item) => item["id"] === post_data_path)) {
          setAttributes({ post_data_path: postDataSelection[0]["id"] });
        }
      }
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps() }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "feedback" }, content_path), /* @__PURE__ */ wp.element.createElement(ServerSideRender, { block: "catpow/form", attributes, httpMethod: "POST" })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(PanelBody, { title: __("\u30D5\u30A9\u30FC\u30E0", "catpow") }, /* @__PURE__ */ wp.element.createElement(
        TreeSelect,
        {
          label: "path",
          selectedId: content_path,
          tree: Object.values(cpEmbeddablesTree.form),
          onChange: (content_path2) => {
            setAttributes({ content_path: content_path2 });
          }
        }
      ), postDataSelection && /* @__PURE__ */ wp.element.createElement(
        TreeSelect,
        {
          label: "form",
          selectedId: post_data_path,
          tree: postDataSelection,
          onChange: (post_data_path2) => {
            setAttributes({ post_data_path: post_data_path2 });
          }
        }
      )), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: __("\u5165\u529B\u5024", "catpow"), initialOpen: false }, /* @__PURE__ */ wp.element.createElement(
        TextControl,
        {
          label: __("\u5165\u529B\u540D", "catpow"),
          value: inputs,
          onChange: (inputs2) => {
            setAttributes({ inputs: inputs2 });
          }
        }
      ), /* @__PURE__ */ wp.element.createElement(
        TextControl,
        {
          label: __("\u30C7\u30FC\u30BFID", "catpow"),
          value: data_id,
          onChange: (data_id2) => {
            setAttributes({ data_id: data_id2 });
          }
        }
      ), /* @__PURE__ */ wp.element.createElement(
        TextareaControl,
        {
          label: __("\u521D\u671F\u5024", "catpow"),
          value: values,
          onChange: (values2) => {
            setAttributes({ values: values2 });
          }
        }
      ))));
    },
    save({ attributes, className, setAttributes }) {
      return false;
    }
  });
})();
