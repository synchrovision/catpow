(() => {
  // ../blocks/formblock/block.json
  var allowedBlocks = [
    "catpow/formblockcontent"
  ];

  // ../blocks/formblock/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/formblock", {
    apiVersion: 3,
    icon: "editor-code",
    category: "catpow-embed",
    example: CP.example,
    edit({ attributes, setAttributes, className, isSelected, clientId }) {
      const { InnerBlocks, BlockControls, InspectorControls, useBlockProps } = wp.blockEditor;
      const { PanelBody, TreeSelect, TextareaControl, TextControl, ToolbarGroup } = wp.components;
      const { content_path, inputs, data_id, values, actions, EditMode = false } = attributes;
      if (!actions && content_path) {
        const path = content_path.slice(0, content_path.lastIndexOf("/"));
        wp.apiFetch({ path: "cp/v1/" + path + "/actions" }).then((actions2) => {
          Object.keys(actions2).map((key) => actions2[key].json = "action");
          setAttributes({ actions: actions2 });
        });
      }
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(
        ToolbarGroup,
        {
          controls: [
            {
              icon: "edit",
              title: "EditMode",
              isActive: EditMode,
              onClick: () => setAttributes({ EditMode: !EditMode })
            }
          ]
        }
      )), /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps({ className: "formBlock cp-embeddedcontent" + (EditMode ? " editMode" : "") }) }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "feedback" }, content_path || "not selected"), /* @__PURE__ */ wp.element.createElement(InnerBlocks, { allowedBlocks })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(PanelBody, { title: __("\u30D5\u30A9\u30FC\u30E0", "catpow") }, /* @__PURE__ */ wp.element.createElement(
        TreeSelect,
        {
          label: "path",
          selectedId: content_path,
          tree: Object.values(cpEmbeddablesTree.formblock || {}),
          onChange: (content_path2) => {
            const path = content_path2.slice(0, content_path2.lastIndexOf("/"));
            wp.apiFetch({ path: "cp/v1/" + path + "/template" }).then((template) => {
              wp.data.dispatch("core/block-editor").replaceInnerBlocks(clientId, CP.createBlocks(template));
            });
            setAttributes({ content_path: content_path2, actions: null });
          }
        }
      )), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: __("\u5165\u529B\u5024", "catpow"), initialOpen: false }, /* @__PURE__ */ wp.element.createElement(
        TextControl,
        {
          label: __("\u5165\u529B\u540D", "catpow"),
          value: inputs,
          onChange: (inputs2) => {
            setAttributes({ inputs: inputs2 });
          }
        }
      ), /* @__PURE__ */ wp.element.createElement(
        TextControl,
        {
          label: __("\u30C7\u30FC\u30BFID", "catpow"),
          value: data_id,
          onChange: (data_id2) => {
            setAttributes({ data_id: data_id2 });
          }
        }
      ), /* @__PURE__ */ wp.element.createElement(
        TextareaControl,
        {
          label: __("\u521D\u671F\u5024", "catpow"),
          value: values,
          onChange: (values2) => {
            setAttributes({ values: values2 });
          }
        }
      ))));
    },
    save({ attributes, className, setAttributes }) {
      const { InnerBlocks } = wp.blockEditor;
      return /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null);
    }
  });
  wp.blocks.registerBlockType("catpow/formblockcontent", {
    apiVersion: 3,
    icon: "editor-code",
    category: "catpow",
    edit({ attributes, className, setAttributes, clientId }) {
      const { InnerBlocks, InspectorControls, useBlockProps } = wp.blockEditor;
      const { PanelBody, TextControl } = wp.components;
      const { name } = attributes;
      const parentClientId = wp.data.select("core/block-editor").getBlockParentsByBlockName(clientId, "catpow/formblock")[0];
      const parentBlock = wp.data.select("core/block-editor").getBlock(parentClientId);
      const actions = parentBlock.attributes.actions;
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps({ className: "formBlockContent cp-embeddedcontent" }) }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, name), /* @__PURE__ */ wp.element.createElement(InnerBlocks, { template: [["catpow/section"]], templateLock: false })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(PanelBody, { title: __("\u8A2D\u5B9A", "catpow"), initialOpen: true }, /* @__PURE__ */ wp.element.createElement(
        TextControl,
        {
          label: __("\u540D\u524D", "catpow"),
          value: name,
          onChange: (name2) => {
            setAttributes({ name: name2 });
          }
        }
      )), actions && /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30A2\u30AF\u30B7\u30E7\u30F3", "catpow"), icon: "edit", ...{ setAttributes, attributes }, selectiveClasses: actions, initialOpen: true })));
    },
    save({ attributes, className, setAttributes }) {
      const { InnerBlocks } = wp.blockEditor;
      const { name, action } = attributes;
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("form-block-content", { name, action }, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null)));
    }
  });
})();
