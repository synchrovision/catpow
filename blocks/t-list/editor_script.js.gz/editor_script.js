(() => {
  // ../blocks/t-list/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/t-list", {
    icon: "editor-code",
    category: "catpow-mail",
    example: CP.example,
    edit({ attributes, className, setAttributes }) {
      const { useState, useMemo } = wp.element;
      const { InspectorControls, RichText, useBlockProps } = wp.blockEditor;
      const { PanelBody, TextareaControl } = wp.components;
      const { classes, marginTop, marginBottom, marginBetween, markerSize, markerWidth, markerAlign, markerMargin, markerClasses, markerIndexSize, markerIndexPad, prefix, suffix, items } = attributes;
      var states = CP.classNamesToFlags(classes);
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          "fontSize",
          "fontWeight",
          { name: "marginTop", input: "range", label: __("\u4E0A\u9593\u9694", "catpow"), key: "marginTop", min: 0, max: 4, step: 0.25 },
          { name: "marginBetween", input: "range", label: __("\u9593\u9694", "catpow"), key: "marginBetween", min: 0, max: 4, step: 0.25 },
          { name: "marginBottom", input: "range", label: __("\u4E0B\u9593\u9694", "catpow"), key: "marginBottom", min: 0, max: 4, step: 0.25 },
          {
            name: "isOrdered",
            label: __("\u756A\u53F7\u4ED8\u304D\u30EA\u30B9\u30C8", "catpow"),
            values: "isOrdered",
            sub: [
              { name: "markerIndexSize", input: "range", label: __("\u756A\u53F7\u30B5\u30A4\u30BA", "catpow"), key: "markerIndexSize", min: 1, max: 3, step: 0.1, unit: "em" },
              { name: "markerIndexPad", input: "range", label: __("\u756A\u53F7\u306E\u6841\u6570", "catpow"), key: "markerIndexPad", min: 1, max: 4 }
            ]
          },
          {
            name: "markerColor",
            type: "buttons",
            label: __("\u30DE\u30FC\u30AB\u30FC\u8272", "catpow"),
            values: {
              hasMarkerColorText: __("\u6587\u5B57", "catpow"),
              hasMarkerColorMain: __("\u57FA\u672C", "catpow"),
              hasMarkerColorAccent: __("\u5F37\u8ABF", "catpow"),
              hasMarkerColorHighlight: __("\u5F37\u8ABF\u6587\u5B57", "catpow")
            }
          },
          { name: "markerWeigth", preset: "fontWeight", label: __("\u30DE\u30FC\u30AB\u30FC\u592A\u3055", "catpow"), classKey: "markerClasses" },
          { name: "markerSize", input: "range", label: __("\u30DE\u30FC\u30AB\u30FC\u30B5\u30A4\u30BA", "catpow"), key: "markerSize", min: 1, max: 4, step: 0.1, unit: "em" },
          { name: "markerWidth", input: "range", label: __("\u30DE\u30FC\u30AB\u30FC\u5E45", "catpow"), key: "markerWidth", min: 1, max: 8, step: 0.25, unit: "em" },
          { name: "markerMargin", input: "range", label: __("\u30DE\u30FC\u30AB\u30FC\u9593\u9694", "catpow"), key: "markerMargin", min: 0.1, max: 2, step: 0.1, unit: "em" },
          { name: "markerAlign", input: "buttons", label: __("\u30DE\u30FC\u30AB\u30FC\u4F4D\u7F6E", "catpow"), key: "markerAlign", options: ["left", "center", "right"] }
        ];
        wp.hooks.applyFilters("catpow.blocks.t-list.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { ...useBlockProps({ className: classes }), width: "100%", align: "center" }, /* @__PURE__ */ wp.element.createElement("tbody", null, marginTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginTop}em` }, colspan: "3" })), items.map((item, index) => /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, index > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginBetween}em` }, colspan: "3" })), /* @__PURE__ */ wp.element.createElement("tr", { className: "item_" }, /* @__PURE__ */ wp.element.createElement("td", { className: markerClasses, width: markerWidth, align: markerAlign, style: { width: markerWidth, textAlign: markerAlign, fontSize: markerSize } }, /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          className: "_prefix",
          tagName: "span",
          onChange: (prefix2) => {
            setAttributes({ prefix: prefix2 });
          },
          value: prefix
        }
      ), states.isOrdered && /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("span", { className: "_index", style: { fontSize: markerIndexSize } }, markerIndexPad > 1 ? (index + 1).toString().padStart(markerIndexPad, "0") : index + 1), /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          className: "_suffix",
          tagName: "span",
          onChange: (suffix2) => {
            setAttributes({ suffix: suffix2 });
          },
          value: suffix
        }
      ))), /* @__PURE__ */ wp.element.createElement("td", { className: "_spacer", width: markerMargin, style: { width: markerMargin } }), /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          className: "_text",
          tagName: "td",
          onChange: (text) => {
            items[index].text = text;
            setAttributes({ items: JSON.parse(JSON.stringify(items)) });
          },
          value: item.text
        }
      )))), marginBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginBottom}em` }, colspan: "3" }))))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30AF\u30E9\u30B9", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses, initialOpen: true }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: __("\u30AF\u30E9\u30B9", "catpow"), onChange: (classes2) => setAttributes({ classes: classes2 }), value: classes }))));
    },
    save({ attributes, className, setAttributes }) {
      const { RichText, useBlockProps } = wp.blockEditor;
      const { classes, marginTop, marginBottom, marginBetween, markerSize, markerWidth, markerAlign, markerMargin, markerClasses, markerIndexSize, markerIndexPad, prefix, suffix, items } = attributes;
      var states = CP.classNamesToFlags(classes);
      return /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { ...useBlockProps.save({ className: classes }), width: "100%", align: "center" }, /* @__PURE__ */ wp.element.createElement("tbody", null, marginTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginTop}em` }, colspan: "3" })), items.map((item, index) => /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, index > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginBetween}em` }, colspan: "3" })), /* @__PURE__ */ wp.element.createElement("tr", { className: "item_" }, /* @__PURE__ */ wp.element.createElement("td", { className: markerClasses, width: markerWidth, align: markerAlign, style: { width: markerWidth, textAlign: markerAlign, fontSize: markerSize } }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { className: "_prefix", tagName: "span", value: prefix }), states.isOrdered && /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("span", { className: "_index", style: { fontSize: markerIndexSize } }, markerIndexPad > 1 ? (index + 1).toString().padStart(markerIndexPad, "0") : index + 1), /* @__PURE__ */ wp.element.createElement(RichText.Content, { className: "_suffix", tagName: "span", value: suffix }))), /* @__PURE__ */ wp.element.createElement("td", { className: "_spacer", width: markerMargin, style: { width: markerMargin } }), /* @__PURE__ */ wp.element.createElement(RichText.Content, { className: "_text", tagName: "td", value: item.text })))), marginBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${marginBottom}em` }, colspan: "3" })))));
    }
  });
})();
