(() => {
  // ../blocks/formbuttons/editor_script.jsx
  var blockConfig = {
    linkKeys: {
      link: { href: "action", items: "items" }
    }
  };
  CP.config.formbuttons = blockConfig;
  wp.blocks.registerBlockType("catpow/formbuttons", {
    title: "\u{1F43E} FormButtons",
    description: "\u30D5\u30A9\u30FC\u30E0\u7528\u306E\u30DC\u30BF\u30F3\u3067\u3059\u3002",
    icon: "upload",
    category: "catpow",
    example: CP.example,
    edit({ attributes, className, setAttributes, isSelected }) {
      const { useMemo } = wp.element;
      const { BlockControls, InspectorControls, useBlockProps } = wp.blockEditor;
      const { Icon, PanelBody, TextareaControl } = wp.components;
      const { items = [], classes = "", EditMode = false } = attributes;
      const { linkKeys } = blockConfig;
      const states = CP.classNamesToFlags(classes);
      const selectiveClasses = useMemo(() => {
        var selectiveClasses2 = [
          "level",
          "hasMargin",
          "contentWidth",
          "itemSize",
          { name: "microcopy", label: "\u30DE\u30A4\u30AF\u30ED\u30B3\u30D4\u30FC", values: "hasMicroCopy" },
          { name: "caption", label: "\u30AD\u30E3\u30D7\u30B7\u30E7\u30F3", values: "hasCaption" }
        ];
        wp.hooks.applyFilters("catpow.blocks.formbuttons.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const selectiveItemClasses = useMemo(() => {
        const selectiveItemClasses2 = [
          "color",
          "rank",
          {
            name: "icon",
            label: "\u30A2\u30A4\u30B3\u30F3",
            values: "hasIcon",
            sub: [{ input: "icon" }]
          },
          "event"
        ];
        wp.hooks.applyFilters("catpow.blocks.formbuttons.selectiveItemClasses", CP.finderProxy(selectiveItemClasses2));
        return selectiveItemClasses2;
      }, []);
      const saveItems = () => {
        setAttributes({ items: JSON.parse(JSON.stringify(items)) });
      };
      const blockProps = useBlockProps({
        className: classes
      });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectModeToolbar, { set: setAttributes, attr: attributes }), EditMode ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps, className: "cp-altcontent" }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, /* @__PURE__ */ wp.element.createElement(Icon, { icon: "edit" })), /* @__PURE__ */ wp.element.createElement(
        CP.EditItemsTable,
        {
          set: setAttributes,
          attr: attributes,
          columns: [
            { type: "text", key: "copy", cond: states.hasMicroCopy },
            { type: "text", key: "text", cond: true },
            { type: "text", key: "caption", cond: states.hasCaption },
            { type: "text", key: "action", cond: true }
          ],
          isTemplate: states.isTemplate
        }
      )) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { ...blockProps }, items.map((item, index) => {
        if (!item.controlClasses) {
          item.controlClasses = "control";
        }
        const itemStates = CP.classNamesToFlags(item.classes);
        return /* @__PURE__ */ wp.element.createElement(CP.Item, { className: item.classes, tag: "li", set: setAttributes, attr: attributes, items, index, isSelected, key: index }, states.hasMicroCopy && /* @__PURE__ */ wp.element.createElement(
          "span",
          {
            className: "_copy",
            onInput: (e) => {
              item.copy = e.target.innerText;
            },
            onBlur: (e) => {
              saveItems();
            },
            contentEditable: true,
            suppressContentEditableWarning: true
          },
          item.copy
        ), /* @__PURE__ */ wp.element.createElement(CP.Link.Edit, { className: "-button", attr: attributes, set: setAttributes, keys: linkKeys.link, index }, itemStates.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item }), /* @__PURE__ */ wp.element.createElement(
          "span",
          {
            className: "_text",
            onInput: (e) => {
              item.text = e.target.innerText;
            },
            onBlur: saveItems,
            contentEditable: true,
            suppressContentEditableWarning: true
          },
          item.text
        )), states.hasCaption && /* @__PURE__ */ wp.element.createElement(
          "span",
          {
            className: "_caption",
            onInput: (e) => {
              item.caption = e.target.innerText;
            },
            onBlur: (e) => {
              saveItems();
            },
            contentEditable: true,
            suppressContentEditableWarning: true
          },
          item.caption
        ));
      }))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u30AF\u30E9\u30B9", icon: "art", set: setAttributes, attr: attributes, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u30DC\u30BF\u30F3", icon: "edit", set: setAttributes, attr: attributes, items, index: attributes.currentItemIndex, selectiveClasses: selectiveItemClasses }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: "\u30AF\u30E9\u30B9", onChange: (classes2) => setAttributes({ classes: classes2 }), value: classes })), /* @__PURE__ */ wp.element.createElement(CP.ItemControlInfoPanel, null)), /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(CP.AlignClassToolbar, { set: setAttributes, attr: attributes })));
    },
    save({ attributes }) {
      const { items = [], classes = "" } = attributes;
      const blockType = wp.data.select("core/blocks").getBlockType("catpow/formbuttons");
      const states = CP.classNamesToFlags(classes);
      return /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { className: classes }, items.map((item, index) => {
        const itemStates = CP.classNamesToFlags(item.classes);
        const eventDispatcherAttributes = {};
        if (blockType.attributes.items.eventDispatcherAttributes) {
          blockType.attributes.items.eventDispatcherAttributes.map((attr_name) => {
            eventDispatcherAttributes[blockType.attributes.items.query[attr_name].attribute] = item[attr_name];
          });
        }
        return /* @__PURE__ */ wp.element.createElement("li", { className: item.classes, key: index }, states.hasMicroCopy && /* @__PURE__ */ wp.element.createElement("span", { className: "_copy" }, item.copy), /* @__PURE__ */ wp.element.createElement(
          "div",
          {
            className: "-button",
            role: "button",
            "data-action": item.action,
            "data-callback": item.callback,
            "data-target": item.target,
            "ignore-message": item.ignoreMessage,
            ...eventDispatcherAttributes
          },
          itemStates.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item }),
          /* @__PURE__ */ wp.element.createElement("span", { className: "_text" }, item.text)
        ), states.hasCaption && /* @__PURE__ */ wp.element.createElement("span", { className: "_caption" }, item.caption));
      })));
    },
    deprecated: [
      {
        attributes: {
          version: { type: "number", default: 0 },
          classes: {
            source: "attribute",
            selector: "ul",
            attribute: "class",
            default: "wp-block-catpow-formbuttons buttons"
          },
          items: {
            source: "query",
            selector: "li.item",
            query: {
              classes: { source: "attribute", attribute: "class" },
              event: { source: "attribute", attribute: "data-event" },
              button: { source: "text" }
            },
            default: [{ classes: "item", button: "[button \u9001\u4FE1 send]" }]
          }
        },
        save({ attributes, className }) {
          const { items = [], classes = "" } = attributes;
          var classArray = _.uniq(classes.split(" "));
          let rtn = [];
          items.map((item, index) => {
            rtn.push(
              /* @__PURE__ */ wp.element.createElement("li", { className: item.classes, "data-event": item.event }, item.button)
            );
          });
          return /* @__PURE__ */ wp.element.createElement("ul", { className: classes }, rtn);
        },
        migrate(attributes) {
          const { items = [] } = attributes;
          const parseButtonShortCode = (code) => {
            let matches = code.match(/^\[button ([^ ]+) ([^ ]+)( ignore_message\=1)?\]$/);
            if (matches) {
              let rtn = { content: matches[1], action: matches[2] };
              if (matches[3]) {
                rtn.ignore_message = 1;
              }
              return rtn;
            }
            return { content: "\u9001\u4FE1" };
          };
          items.map((item) => {
            const buttonData = parseButtonShortCode(item.button);
            item.action = buttonData.action;
            item.text = buttonData.content;
            item.ignore_message = buttonData.ignore_message;
          });
          return attributes;
        }
      }
    ]
  });
})();
