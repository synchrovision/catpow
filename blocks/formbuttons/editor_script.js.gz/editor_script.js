(() => {
  // ../blocks/formbuttons/editor_script.jsx
  var { __ } = wp.i18n;
  var blockConfig = {
    linkKeys: {
      link: { href: "action", items: "items" }
    }
  };
  CP.config.formbuttons = blockConfig;
  wp.blocks.registerBlockType("catpow/formbuttons", {
    icon: "upload",
    category: "catpow",
    example: CP.example,
    edit({ attributes, className, setAttributes, isSelected }) {
      const { useMemo } = wp.element;
      const { BlockControls, InspectorControls, useBlockProps } = wp.blockEditor;
      const { isTemplate, items = [], classes = "", vars, EditMode = false } = attributes;
      const { linkKeys } = blockConfig;
      const states = CP.classNamesToFlags(classes);
      const selectiveClasses = useMemo(() => {
        var selectiveClasses2 = [];
        wp.hooks.applyFilters("catpow.blocks.formbuttons.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const selectiveItemClasses = useMemo(() => {
        const selectiveItemClasses2 = ["color", "buttonParams"];
        wp.hooks.applyFilters("catpow.blocks.formbuttons.selectiveItemClasses", CP.finderProxy(selectiveItemClasses2));
        return selectiveItemClasses2;
      }, []);
      const blockProps = useBlockProps({ className: EditMode ? "cp-altcontent" : classes, style: vars });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectModeToolbar, { setAttributes, attributes }), EditMode ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "edit" }), /* @__PURE__ */ wp.element.createElement(
        CP.EditItemsTable,
        {
          setAttributes,
          attributes,
          columns: [
            { type: "text", key: "copy", cond: states.hasMicroCopy },
            { type: "text", key: "text", cond: true },
            { type: "text", key: "caption", cond: states.hasCaption },
            { type: "text", key: "action", cond: true }
          ],
          isTemplate
        }
      )) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { ...blockProps }, items.map((item, index) => {
        return /* @__PURE__ */ wp.element.createElement(
          CP.Button.Edit,
          {
            tag: "li",
            blockTypeName: "catpow/formbuttons",
            className: item.classes,
            isItem: true,
            ...{ setAttributes, attributes },
            itemKeys: ["items", index],
            keys: linkKeys.link,
            key: index
          }
        );
      }))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30AF\u30E9\u30B9", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(
        CP.SelectClassPanel,
        {
          title: __("\u30DC\u30BF\u30F3", "catpow"),
          icon: "edit",
          ...{ setAttributes, attributes },
          itemKeys: ["items", attributes.currentItemIndex],
          classKey: "buttonClasses",
          selectiveClasses: selectiveItemClasses
        }
      ), /* @__PURE__ */ wp.element.createElement(CP.ItemControlInfoPanel, null)), /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(CP.AlignClassToolbar, { setAttributes, attributes })));
    },
    save({ attributes }) {
      const { useBlockProps } = wp.blockEditor;
      const { items = [], classes = "", vars } = attributes;
      return /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { ...useBlockProps.save({ className: classes, style: vars }) }, items.map((item, index) => /* @__PURE__ */ wp.element.createElement(
        CP.Button,
        {
          tag: "li",
          blockTypeName: "catpow/formbuttons",
          isLink: false,
          ...{ attributes },
          itemKeys: ["items", index],
          keys: blockConfig.linkKeys.link,
          "data-action": item.action,
          "data-callback": item.callback,
          "data-target": item.target,
          "ignore-message": item.ignoreMessage,
          key: index
        }
      ))));
    }
  });
})();
