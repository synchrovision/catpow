(() => {
  // ../blocks/widget/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/widget", {
    title: "\u{1F43E} Widget",
    description: __("\u62E1\u5F35\u6A5F\u80FD\u306B\u5B9A\u7FA9\u3055\u308C\u305F\u57CB\u3081\u8FBC\u307F\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u8868\u793A\u3057\u307E\u3059\u3002", "catpow"),
    icon: "editor-code",
    category: "catpow-embed",
    example: CP.example,
    edit({ attributes, setAttributes, className }) {
      const { InspectorControls, useBlockProps } = wp.blockEditor;
      const { PanelBody, TreeSelect } = wp.components;
      const { serverSideRender: ServerSideRender } = wp;
      const { func, param } = attributes;
      const statesClasses = func ? cpEmbeddablesTree.widget[func].conf : false;
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps({ className: "cp-embeddedcontent" }) }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, func), /* @__PURE__ */ wp.element.createElement(ServerSideRender, { block: "catpow/widget", attributes })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "Path" }, /* @__PURE__ */ wp.element.createElement(
        TreeSelect,
        {
          label: "path",
          selectedId: func,
          tree: Object.values(cpEmbeddablesTree.widget),
          onChange: (func2) => {
            setAttributes({ func: func2 });
          }
        }
      )), statesClasses && /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { initialOpen: true, title: __("\u8A2D\u5B9A", "catpow"), icon: "admin-appearance", ...{ setAttributes, attributes }, selectiveClasses: statesClasses })));
    },
    save({ attributes, className, setAttributes }) {
      return "null";
    }
  });
})();
