(() => {
  // ../blocks/contactinfo/editor_script.jsx
  var { __ } = wp.i18n;
  CP.config.contactinfo = {
    linkKeys: {
      link: { href: "href", items: "items" }
    }
  };
  var getSubHeadingTag = (HeadingTag) => HeadingTag.replace(/h(\d)/, (m, num) => `h${Math.min(parseInt(num) + 1, 6)}`);
  wp.blocks.registerBlockType("catpow/contactinfo", {
    description: __("\u304A\u554F\u3044\u5408\u308F\u305B\u306E\u96FB\u8A71\u756A\u53F7\u3084\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9\u3092\u8A18\u8F09\u3059\u308B\u305F\u3081\u306E\u30D6\u30ED\u30C3\u30AF\u3067\u3059\u3002", "catpow"),
    example: CP.example,
    edit({ attributes, className, setAttributes, isSelected }) {
      const { useMemo, useEffect } = wp.element;
      const { InnerBlocks, InspectorControls, RichText, useBlockProps } = wp.blockEditor;
      const { Icon, PanelBody, TextareaControl } = wp.components;
      const { isTemplate, classes, vars, HeadingTag = "h3", itemsClasses, items = [], title, lead, caption, loopCount, doLoop, EditMode = false, AltMode = false } = attributes;
      const { classNamesToFlags, flagsToClassNames } = Catpow.util;
      const states = useMemo(() => classNamesToFlags(classes), [classes]);
      const { linkKeys } = CP.config.contactinfo;
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          { name: "title", label: __("\u30BF\u30A4\u30C8\u30EB", "catpow"), values: "hasTitle" },
          { name: "lead", label: __("\u30EA\u30FC\u30C9", "catpow"), values: "hasLead" },
          { name: "caption", label: __("\u30AD\u30E3\u30D7\u30B7\u30E7\u30F3", "catpow"), values: "hasCaption" },
          {
            name: "icon",
            label: __("\u30A2\u30A4\u30B3\u30F3", "catpow"),
            values: "hasIcon",
            sub: [{ input: "icon" }]
          },
          { name: "itemTitle", label: __("\u500B\u5225\u30BF\u30A4\u30C8\u30EB", "catpow"), values: "hasItemTitle", sub: [{ name: "itemsLevel", preset: "level", classKey: "itemsClasses" }] },
          { name: "itemLead", label: __("\u500B\u5225\u30EA\u30FC\u30C9", "catpow"), values: "hasItemLead" },
          {
            name: "itemCaption",
            label: __("\u500B\u5225\u30AD\u30E3\u30D7\u30B7\u30E7\u30F3", "catpow"),
            values: "hasItemCaption"
          },
          "isTemplate"
        ];
        wp.hooks.applyFilters("catpow.blocks.contactinfo.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const selectiveItemClasses = useMemo(() => {
        const selectiveItemClasses2 = ["color", "event"];
        wp.hooks.applyFilters("catpow.blocks.contactinfo.selectiveItemClasses", CP.finderProxy(selectiveItemClasses2));
        return selectiveItemClasses2;
      }, []);
      const save = () => {
        setAttributes({ items: JSON.parse(JSON.stringify(items)) });
      };
      const len = Math.max(items.length, loopCount);
      useEffect(() => {
        states.hasMultipleItems = len > 1;
        setAttributes({ classes: flagsToClassNames(states) });
      }, [len > 1]);
      const blockProps = useBlockProps({ className: classes, style: vars });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectModeToolbar, { setAttributes, attributes }), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30B9\u30BF\u30A4\u30EB", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30A2\u30A4\u30C6\u30E0", "catpow"), icon: "edit", ...{ setAttributes, attributes }, itemKeys: ["items", attributes.currentItemIndex], selectiveClasses: selectiveItemClasses }), /* @__PURE__ */ wp.element.createElement(CP.ItemControlInfoPanel, null)), EditMode ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps, className: "cp-altcontent" }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, /* @__PURE__ */ wp.element.createElement(Icon, { icon: "edit" })), /* @__PURE__ */ wp.element.createElement(
        CP.EditItemsTable,
        {
          setAttributes,
          attributes,
          columns: [
            { type: "text", key: "title", cond: states.hasItemTitle },
            { type: "text", key: "lead", cond: states.hasItemLead },
            { type: "text", key: "link" },
            { type: "text", key: "href" },
            { type: "text", key: "caption", cond: states.hasItemCaption }
          ],
          isTemplate
        }
      )) : /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, AltMode && doLoop ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps, className: "cp-altcontent" }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, /* @__PURE__ */ wp.element.createElement(Icon, { icon: "welcome-comments" })), /* @__PURE__ */ wp.element.createElement(InnerBlocks, null)) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, states.hasTitle && /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          tagName: HeadingTag,
          className: "_title",
          placeholder: "Input Title",
          onChange: (title2) => {
            setAttributes({ title: title2 });
          },
          value: title
        }
      ), states.hasLead && /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          tagName: "p",
          className: "_lead",
          placeholder: "Input Lead",
          onChange: (lead2) => {
            setAttributes({ lead: lead2 });
          },
          value: lead
        }
      ), /* @__PURE__ */ wp.element.createElement("ul", { className: itemsClasses }, [...Array(len).keys()].map((i) => {
        const index = i % items.length;
        const item = items[index];
        return /* @__PURE__ */ wp.element.createElement(CP.Item, { className: "_item", tag: "li", ...{ setAttributes, attributes }, itemKeys: ["items", index], key: i }, states.hasItemTitle && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: getSubHeadingTag(HeadingTag),
            className: "_title",
            placeholder: "Input Title",
            onChange: (title2) => {
              item.title = title2;
              save();
            },
            value: item.title
          }
        ), states.hasItemLead && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "p",
            className: "_lead",
            placeholder: "Input Lead",
            onChange: (lead2) => {
              item.lead = lead2;
              save();
            },
            value: item.lead
          }
        ), /* @__PURE__ */ wp.element.createElement(CP.Link.Edit, { className: "_link", attributes, setAttributes, keys: linkKeys.link, itemKeys: ["items", index] }, states.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item: attributes }), /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "span",
            className: "_text",
            placeholder: "Input Link",
            onChange: (link) => {
              items[index].link = link;
              save();
            },
            value: item.link
          }
        )), states.hasItemCaption && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "small",
            className: "_caption",
            placeholder: "Input Caption",
            onChange: (caption2) => {
              item.caption = caption2;
              save();
            },
            value: item.caption
          }
        ));
      })), states.hasCaption && /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          tagName: "small",
          className: "_caption",
          placeholder: "Input Caption",
          onChange: (caption2) => {
            setAttributes({ caption: caption2 });
          },
          value: caption
        }
      )))));
    },
    save({ attributes }) {
      const { InnerBlocks, RichText, useBlockProps } = wp.blockEditor;
      const { classes, vars, HeadingTag = "h3", itemsClasses, items = [], title, lead, caption, doLoop } = attributes;
      const states = Catpow.util.classNamesToFlags(classes);
      const { linkKeys } = CP.config.contactinfo;
      let rtn = [];
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps.save({ className: classes, style: vars }) }, states.hasTitle && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: HeadingTag, className: "_title", value: title }), states.hasLead && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "p", className: "_lead", value: lead }), /* @__PURE__ */ wp.element.createElement("ul", { className: itemsClasses }, items.map((item, index) => {
        return /* @__PURE__ */ wp.element.createElement("li", { className: "_item", key: index }, states.hasItemTitle && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: getSubHeadingTag(HeadingTag), className: "_title", value: item.title }), states.hasItemLead && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "p", className: "_lead", value: item.lead }), /* @__PURE__ */ wp.element.createElement(CP.Link, { className: "_link", attributes, keys: linkKeys.link, itemKeys: ["items", index], ...CP.extractEventDispatcherAttributes("catpow/contactinfo", item) }, states.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item: attributes }), /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "span", className: "_text", value: item.link })), states.hasItemCaption && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "small", className: "_caption", value: item.caption }));
      })), states.hasLead && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "small", className: "_caption", value: caption }))), doLoop && /* @__PURE__ */ wp.element.createElement("on-empty", null, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null)));
    }
  });
})();
