(() => {
  // node_modules/clsx/dist/clsx.mjs
  function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
      var o = e.length;
      for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for (f in e) e[f] && (n && (n += " "), n += f);
    return n;
  }
  function clsx() {
    for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
  }

  // ../blocks/datatable/editor_script.jsx
  wp.blocks.registerBlockType("catpow/datatable", {
    title: "\u{1F43E} DataTable",
    description: "\u4E00\u884C\u307E\u305F\u306F\uFF11\u5217\u306E\u898B\u51FA\u3057\u3092\u6301\u3064\u30C6\u30FC\u30D6\u30EB\u3067\u3059\u3002",
    icon: "editor-table",
    category: "catpow",
    transforms: {
      from: [
        {
          type: "files",
          isMatch: function(files) {
            if (files[1]) {
              return false;
            }
            return files[0].type === "text/csv";
          },
          priority: 15,
          transform: (files) => {
            var attributes = {
              classes: "wp-block-catpow-datatable spec",
              rows: [{ classes: "", cells: [{ text: ["Title"], classes: "th" }] }],
              file: files[0]
            };
            return wp.blocks.createBlock("catpow/datatable", attributes);
          }
        },
        {
          type: "block",
          blocks: CP.tableConvertibles,
          transform: (attributes) => {
            attributes.classes = "wp-block-catpow-datatable spec";
            return wp.blocks.createBlock("catpow/datatable", attributes);
          }
        },
        {
          type: "block",
          blocks: ["core/table"],
          transform: (attributes) => {
            return wp.blocks.createBlock("catpow/datatable", {
              classes: "wp-block-catpow-datatable spec",
              rows: attributes.body.map((row) => ({
                cells: row.cells.map((cell) => ({
                  text: wp.blocks.parseWithAttributeSchema(cell.content, {
                    source: "html"
                  })
                }))
              }))
            });
          }
        }
      ]
    },
    example: CP.example,
    edit({ attributes, className, setAttributes, isSelected }) {
      const { useState, useMemo } = wp.element;
      const { InnerBlocks, InspectorControls, RichText: RichText2, useBlockProps } = wp.blockEditor;
      const { Icon, PanelBody, TextareaControl } = wp.components;
      const { classes: classes2, vars, rows = [], doLoop, AltMode = false } = attributes;
      var states = CP.classNamesToFlags(classes2);
      if (attributes.file) {
        var reader = new FileReader();
        reader.addEventListener("loadend", () => {
          var attr = {
            classes: "wp-block-catpow-datatable spec hasHeaderRow hasHeaderColumn",
            rows: [],
            file: false
          };
          var csvData = CP.parseCSV(reader.result);
          csvData.map((row, r2) => {
            attr.rows.push({
              classes: "",
              cells: row.map((val) => {
                return { text: [val], classes: "" };
              })
            });
          });
          setAttributes(attr);
        });
        reader.readAsText(attributes.file);
      }
      var statesClasses = [
        { label: "\u30D8\u30C3\u30C0\u884C", values: "hasHeaderRow" },
        { label: "\u30D8\u30C3\u30C0\u5217", values: "hasHeaderColumn" }
      ];
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          {
            name: "type",
            type: "buttons",
            label: "\u30BF\u30A4\u30D7",
            values: {
              isStyleSpec: "spec",
              isStyleSheet: "sheet",
              isStylePlan: "plan"
            }
          },
          {
            name: "loop",
            input: "bool",
            label: "\u30EB\u30FC\u30D7",
            key: "doLoop",
            sub: [
              {
                name: "contentPath",
                label: "content path",
                input: "text",
                key: "content_path"
              },
              { name: "query", label: "query", input: "textarea", key: "query" }
            ]
          }
        ];
        wp.hooks.applyFilters("catpow.blocks.datatable.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const saveItems = () => {
        setAttributes({ rows: JSON.parse(JSON.stringify(rows)) });
      };
      const addRow = (index) => {
        rows.splice(index, 0, rows[index]);
        saveItems();
      };
      const deleteRow = (index) => {
        rows.splice(index, 1);
        saveItems();
      };
      const upRow = (index) => {
        rows.splice(index + 1, 0, rows.splice(index, 1)[0]);
        saveItems();
      };
      const downRow = (index) => {
        rows.splice(index - 1, 0, rows.splice(index, 1)[0]);
        saveItems();
      };
      const addColumn = (index) => {
        rows.map((row) => row.cells.splice(index, 0, row.cells[index]));
        saveItems();
      };
      const deleteColumn = (index) => {
        rows.map((row) => row.cells.splice(index, 1));
        saveItems();
      };
      const upColumn = (index) => {
        rows.map((row) => {
          row.cells.splice(index + 1, 0, row.cells.splice(index, 1)[0]);
        });
        saveItems();
      };
      const downColumn = (index) => {
        rows.map((row) => {
          row.cells.splice(index - 1, 0, row.cells.splice(index, 1)[0]);
        });
        saveItems();
      };
      const blockProps = useBlockProps({ className: classes2, style: vars });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectModeToolbar, { setAttributes, attributes, modes: ["AltMode"] }), /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, AltMode && doLoop ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps, className: "cp-altcontent" }, /* @__PURE__ */ wp.element.createElement("div", { className: "label" }, /* @__PURE__ */ wp.element.createElement(Icon, { icon: "welcome-comments" })), /* @__PURE__ */ wp.element.createElement(InnerBlocks, null)) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { ...blockProps }, states.hasHeaderRow && /* @__PURE__ */ wp.element.createElement("thead", null, /* @__PURE__ */ wp.element.createElement("tr", null, rows[0].cells.map((cell, index) => {
        return /* @__PURE__ */ wp.element.createElement("th", { className: clsx("_th", { "is-spacer": index === 0 && states.hasHeaderColumn && cell.text.length === 0 }), key: index }, /* @__PURE__ */ wp.element.createElement(
          RichText2,
          {
            onChange: (text) => {
              cell.text = text;
              saveItems();
            },
            value: cell.text
          }
        ));
      }))), /* @__PURE__ */ wp.element.createElement("tbody", null, rows.map((row, index) => {
        if (states.hasHeaderRow && index == 0) {
          return false;
        }
        return /* @__PURE__ */ wp.element.createElement("tr", { key: index }, row.cells.map((cell, columnIndex) => {
          var children = [
            /* @__PURE__ */ wp.element.createElement(
              RichText2,
              {
                onChange: (text) => {
                  cell.text = text;
                  saveItems();
                },
                value: cell.text,
                key: "text"
              }
            )
          ];
          if (isSelected && columnIndex == row.cells.length - 1) {
            children.push(
              /* @__PURE__ */ wp.element.createElement(
                CP.ItemControl,
                {
                  className: "is-control-row",
                  controls: {
                    up: () => downRow(index),
                    delete: () => deleteRow(index),
                    clone: () => addRow(index),
                    down: () => upRow(index)
                  }
                }
              )
            );
          }
          if (isSelected && index == rows.length - 1) {
            children.push(
              /* @__PURE__ */ wp.element.createElement(
                CP.ItemControl,
                {
                  className: "is-control-column",
                  controls: {
                    left: () => downColumn(columnIndex),
                    delete: () => deleteColumn(columnIndex),
                    clone: () => addColumn(columnIndex),
                    right: () => upColumn(columnIndex)
                  }
                }
              )
            );
          }
          return wp.element.createElement(states.hasHeaderColumn && columnIndex == 0 ? "th" : "td", { key: columnIndex }, children);
        }));
      }))))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u8868\u793A\u8A2D\u5B9A", icon: "admin-appearance", ...{ setAttributes, attributes }, selectiveClasses: statesClasses }), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u30AF\u30E9\u30B9", icon: "art", ...{ setAttributes, attributes }, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: "\u30AF\u30E9\u30B9", onChange: (classes3) => setAttributes({ classes: classes3 }), value: classes2 }))));
    },
    save({ attributes, className }) {
      const { InnerBlocks, RichText: RichText2, useBlockProps } = wp.blockEditor;
      const { classes: classes2 = "", vars, rows = [], loopParam, doLoop } = attributes;
      var states = CP.classNamesToFlags(classes2);
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { ...useBlockProps.save({ className: classes2, style: vars }) }, states.hasHeaderRow && /* @__PURE__ */ wp.element.createElement("thead", null, /* @__PURE__ */ wp.element.createElement("tr", null, rows[0].cells.map((cell, index) => {
        return /* @__PURE__ */ wp.element.createElement("th", { className: clsx("_th", { "is-spacer": index === 0 && states.hasHeaderColumn && cell.text.length === 0 }), key: index }, /* @__PURE__ */ wp.element.createElement(RichText2.Content, { value: cell.text }));
      }))), /* @__PURE__ */ wp.element.createElement("tbody", null, rows.map((row, index) => {
        if (states.hasHeaderRow && index == 0) {
          return false;
        }
        return /* @__PURE__ */ wp.element.createElement("tr", { key: index }, row.cells.map((cell, columnIndex) => {
          return wp.element.createElement(states.hasHeaderColumn && columnIndex == 0 ? "th" : "td", { key: columnIndex }, /* @__PURE__ */ wp.element.createElement(RichText2.Content, { value: cell.text }));
        }));
      })))), doLoop && /* @__PURE__ */ wp.element.createElement("on-empty", null, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null)));
    },
    deprecated: [
      {
        save({ attributes, className }) {
          const { classes: classes2 = "", rows = [], loopParam } = attributes;
          var states = CP.classNamesToFlags(classes2);
          return /* @__PURE__ */ wp.element.createElement("table", { className: classes2 }, states.hasHeaderRow && /* @__PURE__ */ wp.element.createElement("thead", null, /* @__PURE__ */ wp.element.createElement("tr", null, rows[0].cells.map((cell, index) => {
            return /* @__PURE__ */ wp.element.createElement("th", { className: cell.classes }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { value: cell.text }));
          }))), /* @__PURE__ */ wp.element.createElement("tbody", null, states.doLoop && "[loop_template " + (loopParam || "") + "]", rows.map((row, index) => {
            if (states.hasHeaderRow && index == 0) {
              return false;
            }
            return /* @__PURE__ */ wp.element.createElement("tr", null, row.cells.map((cell, columnIndex) => {
              return wp.element.createElement(states.hasHeaderColumn && columnIndex == 0 ? "th" : "td", { className: cell.classes }, cell.text);
            }));
          }), states.doLoop && "[/loop_template]"));
        },
        migrate(attributes) {
          var states = CP.classNamesToFlags(classes);
          attributes.content_path = attributes.loopParam.split(" ")[0];
          attributes.query = attributes.loopParam.split(" ").slice(1).join("\n");
          attributes.doLoop = states.doLoop;
          return attributes;
        }
      }
    ]
  });
})();
