(() => {
  // ../blocks/t-body/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/t-body", {
    icon: "editor-code",
    category: "catpow-mail",
    supports: {
      multiple: false
    },
    example: CP.example,
    edit({ attributes, className, setAttributes }) {
      const { useState, useMemo, useEffect } = wp.element;
      const { InnerBlocks, BlockControls, InspectorControls, RichText, useBlockProps } = wp.blockEditor;
      const { PanelBody, TextareaControl, ToolbarGroup } = wp.components;
      const { useEntityProp } = wp.coreData;
      const [meta, setMeta] = useEntityProp("postType", wp.data.select("core/editor").getCurrentPostType(), "meta");
      const {
        type,
        isHtmlMail,
        classes,
        headerClasses,
        footerClasses,
        headerText,
        headerPaddingTop,
        headerPaddingBottom,
        footerText,
        footerPaddingTop,
        footerPaddingBottom,
        body_class,
        textMail,
        TextMode = false
      } = attributes;
      const primaryClass = "wp-block-catpow-t-body";
      var states = CP.classNamesToFlags(classes);
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          {
            name: "type",
            input: "buttons",
            label: __("\u30E1\u30FC\u30EB\u30BF\u30A4\u30D7", "catpow"),
            key: "type",
            values: ["plain", "html"],
            sub: {
              html: [
                { name: "textMode", input: "bool", label: __("\u30C6\u30AD\u30B9\u30C8\u30E1\u30FC\u30EB\u7DE8\u96C6\u30E2\u30FC\u30C9", "catpow"), key: "TextMode" },
                {
                  name: "body",
                  type: "gridbuttons",
                  label: __("\u80CC\u666F\u8272", "catpow"),
                  values: { hasBgWhite: __("\u767D", "catpow"), hasBgB: __("\u80CC\u666F\u8272", "catpow"), hasBgS: __("\u5F37\u8ABF\u80CC\u666F\u8272", "catpow"), hasBgBlack: __("\u9ED2", "catpow"), hasBgM: __("\u57FA\u672C\u8272", "catpow"), hasBgA: __("\u5F37\u8ABF\u8272", "catpow") },
                  classKey: "body_class"
                },
                {
                  name: "header",
                  label: __("\u30D8\u30C3\u30C0", "catpow"),
                  values: "hasHeader",
                  sub: [
                    { preset: "colorScheme", classKey: "headerClasses" },
                    {
                      name: "headerBackgroundColor",
                      type: "buttons",
                      label: __("\u30D8\u30C3\u30C0\u80CC\u666F\u8272", "catpow"),
                      values: { hasBgNone: __("\u306A\u3057", "catpow"), hasBgNormal: __("\u901A\u5E38", "catpow"), hasBgStrong: __("\u5F37\u8ABF", "catpow"), hasBgAchromatic: __("\u767D\u9ED2", "catpow") },
                      classKey: "headerClasses"
                    },
                    { name: "range", input: "range", label: __("\u4E0A\u4F59\u767D", "catpow"), key: "headerPaddingTop", min: 0, max: 10 },
                    { name: "range", input: "range", label: __("\u4E0B\u4F59\u767D", "catpow"), key: "headerPaddingBottom", min: 0, max: 10 }
                  ]
                },
                {
                  name: "footer",
                  label: __("\u30D5\u30C3\u30BF", "catpow"),
                  values: "hasFooter",
                  sub: [
                    { preset: "colorScheme", classKey: "footerClasses" },
                    {
                      name: "footerBackgroundColor",
                      type: "buttons",
                      label: __("\u30D5\u30C3\u30BF\u80CC\u666F\u8272", "catpow"),
                      values: { hasBgNone: __("\u306A\u3057", "catpow"), hasBgNormal: __("\u901A\u5E38", "catpow"), hasBgStrong: __("\u5F37\u8ABF", "catpow"), hasBgAchromatic: __("\u767D\u9ED2", "catpow") },
                      classKey: "footerClasses"
                    },
                    { name: "range", input: "range", label: __("\u4E0A\u4F59\u767D", "catpow"), key: "footerPaddingTop", min: 0, max: 10 },
                    { name: "range", input: "range", label: __("\u4E0B\u4F59\u767D", "catpow"), key: "footerPaddingBottom", min: 0, max: 10 }
                  ]
                }
              ]
            },
            effect: (val, states2, { set }) => {
              setMeta({ ...meta, type: val });
              set({ isHtmlMail: val === "html" });
            }
          }
        ];
        wp.hooks.applyFilters("catpow.blocks.t-body.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      useEffect(() => {
        if (meta.type !== type) {
          setAttributes({ type: meta.type });
        }
      }, []);
      const showTextEdit = type === "plain" || TextMode;
      const blockProps = useBlockProps({ className: showTextEdit ? "cp-altcontent" : "cp-mail-body " + body_class });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, showTextEdit ? /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "email" }), /* @__PURE__ */ wp.element.createElement(TextareaControl, { className: "cp-textmail", value: textMail, onChange: (textMail2) => setAttributes({ textMail: textMail2 }), rows: 30 })) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { width: "100%", align: "center", valign: "top", className: classes }, states.hasHeader && /* @__PURE__ */ wp.element.createElement("thead", { className: headerClasses }, headerPaddingTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${headerPaddingTop}rem` } })), /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("th", { className: "_th is-text-cell", align: "center" }, /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          onChange: (headerText2) => {
            setAttributes({ headerText: headerText2 });
          },
          value: headerText
        }
      ))), headerPaddingBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${headerPaddingBottom}rem` } }))), /* @__PURE__ */ wp.element.createElement("tbody", null, /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { align: "center" }, /* @__PURE__ */ wp.element.createElement("div", { className: "-contents" }, /* @__PURE__ */ wp.element.createElement(InnerBlocks, null))))), states.hasFooter && /* @__PURE__ */ wp.element.createElement("tfoot", { className: footerClasses }, footerPaddingTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${footerPaddingTop}rem` } })), /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-text-cell", align: "center" }, /* @__PURE__ */ wp.element.createElement(
        RichText,
        {
          onChange: (footerText2) => {
            setAttributes({ footerText: footerText2 });
          },
          value: footerText
        }
      ))), footerPaddingBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${footerPaddingBottom}rem` } })))))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(
        ToolbarGroup,
        {
          controls: [
            {
              icon: "media-text",
              label: __("\u30C6\u30AD\u30B9\u30C8\u30E1\u30FC\u30EB", "catpow"),
              isActive: TextMode,
              onClick: () => setAttributes({ TextMode: !TextMode })
            }
          ]
        }
      )), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30AF\u30E9\u30B9", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses, initialOpen: true }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: __("\u30AF\u30E9\u30B9", "catpow"), onChange: (classes2) => setAttributes({ classes: classes2 }), value: classes }))));
    },
    save({ attributes, className, setAttributes }) {
      const { InnerBlocks, RichText } = wp.blockEditor;
      const { isHtmlMail, classes, headerClasses, footerClasses, headerText, headerPaddingTop, headerPaddingBottom, footerText, footerPaddingTop, footerPaddingBottom, body_class, textMail } = attributes;
      const states = CP.classNamesToFlags(classes);
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, (!isHtmlMail || textMail) && /* @__PURE__ */ wp.element.createElement("textmail", null, textMail), isHtmlMail && /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("table", { width: "100%", align: "center", className: classes }, states.hasHeader && /* @__PURE__ */ wp.element.createElement("thead", { className: headerClasses }, headerPaddingTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${headerPaddingTop}rem` } })), /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("th", { className: "_th is-text-cell", align: "center" }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { value: headerText }))), headerPaddingBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${headerPaddingBottom}rem` } }))), /* @__PURE__ */ wp.element.createElement("tbody", null, /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { align: "center" }, /* @__PURE__ */ wp.element.createElement("div", { className: "-contents" }, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null))))), states.hasFooter && /* @__PURE__ */ wp.element.createElement("tfoot", { className: footerClasses }, footerPaddingTop > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${footerPaddingTop}rem` } })), /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-text-cell", align: "center" }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { value: footerText }))), footerPaddingBottom > 0 && /* @__PURE__ */ wp.element.createElement("tr", null, /* @__PURE__ */ wp.element.createElement("td", { className: "_td is-spacer-cell", style: { height: `${footerPaddingBottom}rem` } }))))));
    }
  });
})();
