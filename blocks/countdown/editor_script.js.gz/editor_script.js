(() => {
  // ../blocks/countdown/editor_script.jsx
  wp.blocks.registerBlockType("catpow/countdown", {
    title: "\u{1F43E} CountDown",
    icon: "clock",
    category: "catpow-embed",
    example: CP.example,
    supports: {
      customClassName: false
    },
    edit({ attributes, setAttributes, className }) {
      const { useCallback, useMemo } = wp.element;
      const { InspectorControls, useBlockProps } = wp.blockEditor;
      const { classes, vars, target } = attributes;
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = ["hasFontSize", { name: "target", label: "\u76EE\u6A19\u65E5\u6642", key: "target", input: "text", placeholder: "2099-12-31 23:59:59" }];
        wp.hooks.applyFilters("catpow.blocks.countdown.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps({ className: classes, style: vars }) }, /* @__PURE__ */ wp.element.createElement(Catpow.CountDown, { target })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, selectiveClasses && /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u8A2D\u5B9A", icon: "edit", ...{ setAttributes, attributes }, selectiveClasses, initialOpen: true })));
    },
    save({ attributes, className, setAttributes }) {
      const { classes = "", vars, target } = attributes;
      const { useBlockProps } = wp.blockEditor;
      return /* @__PURE__ */ wp.element.createElement("div", { ...useBlockProps.save({ className: classes, style: vars, "data-target": target }) });
    }
  });
})();
