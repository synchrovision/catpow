(() => {
  // ../blocks/section/editor_script.jsx
  var { __ } = wp.i18n;
  CP.config.section = {
    devices: ["tb", "sp"],
    imageKeys: {
      navIcon: { src: "navIcon" },
      titleImage: { mime: "titleImageMime", src: "titleImageSrc", alt: "titleImageAlt", srcset: "titleImageSrcset", sources: "titleImageSources" },
      headerImage: { mime: "headerImageMime", src: "headerImageSrc", alt: "headerImageAlt", srcset: "headerImageSrcset", sources: "headerImageSources" },
      decoration: { pictures: "decoration" }
    }
  };
  wp.blocks.registerBlockType("catpow/section", {
    example: CP.example,
    edit(props) {
      const { InnerBlocks, BlockControls, InspectorControls, RichText, useBlockProps } = wp.blockEditor;
      const { PanelBody, TextareaControl, TextControl } = wp.components;
      const { attributes, setAttributes } = props;
      const { useMemo, useState } = wp.element;
      const { isTemplate, SectionTag, HeadingTag, color, anchor, classes, bodyClasses, headerClasses, titleClasses, vars, headerVars, bodyVars, title, lead, titleImageCode, headerImageCode } = attributes;
      const states = CP.classNamesToFlags(classes);
      const { devices, imageKeys } = CP.config.section;
      const [mainBlock, setMainBlock] = useState();
      const selectiveClasses = useMemo(() => {
        const { devices: devices2, imageKeys: imageKeys2 } = CP.config.section;
        const selectiveClasses2 = [
          { name: "sectionTag", input: "buttons", key: "SectionTag", label: __("\u30BB\u30AF\u30B7\u30E7\u30F3\u30BF\u30B0", "catpow"), values: ["article", "section", "aside", "div"], required: true },
          {
            name: "type",
            label: __("\u30BF\u30A4\u30D7", "catpow"),
            type: "gridbuttons",
            values: { isTypeScene: "scene", isTypeArticle: "aticle", isTypeColumn: "column" },
            required: true,
            sub: {
              isTypeScene: [
                {
                  name: "hasContentWidth",
                  label: __("\u30D8\u30C3\u30C0\u30B3\u30F3\u30C6\u30F3\u30C4\u5E45", "catpow"),
                  classKey: "titleClasses",
                  values: "hasContentWidth",
                  sub: [
                    {
                      name: "headerContentWidth",
                      preset: "contentWidth",
                      label: false,
                      vars: "headerVars",
                      classKey: "headerClasses"
                    }
                  ]
                },
                { name: "titleImage", label: __("\u30BF\u30A4\u30C8\u30EB\u753B\u50CF", "catpow"), values: "hasTitleImage", sub: [{ input: "picture", keys: imageKeys2.titleImage, devices: devices2 }] },
                { preset: "clipPath", label: __("\u30D8\u30C3\u30C0\u30AF\u30EA\u30C3\u30D7", "catpow"), name: "headerClip", classKey: "headerClasses", vars: "headerVars" }
              ],
              isTypeArticle: ["headingType"],
              isTypeColumn: [
                { preset: "itemSize", label: __("\u30D8\u30C3\u30C0\u30B5\u30A4\u30BA", "catpow"), name: "headerSize", classKey: "headerClasses", vars: "headerVars" },
                { preset: "hasBorderImage", classKey: "bodyClasses" }
              ]
            },
            bind: {
              isTypeArticle: {
                bodyClasses: ["hasContentWidth"]
              },
              isTypeColumn: {
                bodyClasses: ["hasContentWidth"]
              }
            }
          },
          "align",
          { preset: "textAlign", classKey: "headerClasses" },
          { preset: "colorScheme", label: __("\u30D8\u30C3\u30C0\u914D\u8272", "catpow"), classKey: "headerClasses" },
          { preset: "backgroundColor", label: __("\u30D8\u30C3\u30C0\u80CC\u666F\u8272", "catpow"), name: "headerBackgroundColor", classKey: "headerClasses" },
          { preset: "backgroundImage", label: __("\u30D8\u30C3\u30C0\u80CC\u666F\u753B\u50CF", "catpow"), name: "headerBackgroundImage", classKey: "headerClasses", vars: "headerVars" },
          { preset: "backgroundPattern", label: __("\u30D8\u30C3\u30C0\u80CC\u666F\u30D1\u30BF\u30FC\u30F3", "catpow"), name: "headerBackgroundPattern", classKey: "headerClasses", vars: "headerVars" },
          { name: "headerImage", label: __("\u30D8\u30C3\u30C0\u753B\u50CF", "catpow"), values: "hasHeaderImage", sub: [{ input: "picture", keys: imageKeys2.headerImage }] },
          "hasIcon",
          { name: "lead", label: __("\u30EA\u30FC\u30C9", "catpow"), values: "hasLead" },
          { name: "decoration", label: __("\u30C7\u30B3\u30EC\u30FC\u30B7\u30E7\u30F3", "catpow"), values: "hasDecoration" },
          {
            name: "navIcon",
            label: __("\u30E1\u30CB\u30E5\u30FC\u30A2\u30A4\u30B3\u30F3", "catpow"),
            values: "hasNavIcon",
            sub: [{ input: "image", label: __("\u30A2\u30A4\u30B3\u30F3", "catpow"), keys: imageKeys2.navIcon, size: "thumbnail" }]
          }
        ];
        wp.hooks.applyFilters("catpow.blocks.section.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const blockProps = useBlockProps({
        id: anchor,
        className: classes,
        style: vars
      });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(CP.AlignClassToolbar, { setAttributes, attributes })), /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement(SectionTag, { ref: setMainBlock, ...blockProps }, /* @__PURE__ */ wp.element.createElement("div", { className: bodyClasses, style: bodyVars }, states.hasDecoration && /* @__PURE__ */ wp.element.createElement(CP.PlacedPictures.Edit, { className: "decoration_", setAttributes, attributes, devices, keys: imageKeys.decoration }), /* @__PURE__ */ wp.element.createElement("header", { className: headerClasses, style: headerVars }, states.hasHeaderImage && /* @__PURE__ */ wp.element.createElement("div", { className: "_image" }, isTemplate && headerImageCode ? /* @__PURE__ */ wp.element.createElement(CP.DummyImage, { text: headerImageCode }) : /* @__PURE__ */ wp.element.createElement(CP.SelectResponsiveImage, { className: "_picture", setAttributes, attributes, keys: imageKeys.headerImage })), /* @__PURE__ */ wp.element.createElement("div", { className: titleClasses }, states.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item: attributes }), states.hasTitleImage ? /* @__PURE__ */ wp.element.createElement(HeadingTag, { className: "_titleimage" }, isTemplate && titleImageCode ? /* @__PURE__ */ wp.element.createElement(CP.DummyImage, { text: titleImageCode }) : /* @__PURE__ */ wp.element.createElement(CP.SelectResponsiveImage, { className: "_image", setAttributes, attributes, keys: imageKeys.titleImage, devices })) : /* @__PURE__ */ wp.element.createElement(RichText, { tagName: HeadingTag, className: "_heading", value: title, placeholder: "Title", onChange: (title2) => setAttributes({ title: title2 }) }), states.hasLead && /* @__PURE__ */ wp.element.createElement(RichText, { tagName: "div", className: "_lead", value: lead, placeholder: "Lead", onChange: (lead2) => setAttributes({ lead: lead2 }) }))), /* @__PURE__ */ wp.element.createElement("div", { className: "contents_" }, /* @__PURE__ */ wp.element.createElement(InnerBlocks, null))))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.ColorVarTracer, { target: mainBlock }, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30B9\u30BF\u30A4\u30EB", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses, initialOpen: true }))));
    },
    save({ attributes }) {
      const { InnerBlocks, RichText, useBlockProps } = wp.blockEditor;
      const { isTemplate, SectionTag, HeadingTag, anchor, navIcon, classes, bodyClasses, headerClasses, titleClasses, vars, headerVars, bodyVars, title, lead, titleImageCode, headerImageCode } = attributes;
      const states = CP.classNamesToFlags(classes);
      const { devices, imageKeys } = CP.config.section;
      const blockProps = useBlockProps.save({
        id: anchor,
        className: classes,
        style: vars
      });
      return /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement(SectionTag, { "data-icon": navIcon, ...blockProps }, /* @__PURE__ */ wp.element.createElement("div", { className: bodyClasses, style: bodyVars }, states.hasDecoration && /* @__PURE__ */ wp.element.createElement(CP.PlacedPictures, { className: "decoration_", attributes, keys: imageKeys.decoration }), /* @__PURE__ */ wp.element.createElement("header", { className: headerClasses, style: headerVars }, states.hasHeaderImage && /* @__PURE__ */ wp.element.createElement("div", { className: "_image" }, isTemplate && headerImageCode ? headerImageCode : /* @__PURE__ */ wp.element.createElement(CP.ResponsiveImage, { className: "_picture", attributes, keys: imageKeys.headerImage })), /* @__PURE__ */ wp.element.createElement("div", { className: titleClasses }, states.hasIcon && /* @__PURE__ */ wp.element.createElement(CP.OutputIcon, { className: "_icon", item: attributes }), states.hasTitleImage ? /* @__PURE__ */ wp.element.createElement(HeadingTag, { className: "_titleimage" }, isTemplate && titleImageCode ? titleImageCode : /* @__PURE__ */ wp.element.createElement(CP.ResponsiveImage, { className: "_image", attributes, keys: imageKeys.titleImage, devices })) : /* @__PURE__ */ wp.element.createElement(HeadingTag, { className: "_heading" }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { value: title })), states.hasLead && /* @__PURE__ */ wp.element.createElement("div", { className: "_lead" }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { value: lead })))), /* @__PURE__ */ wp.element.createElement("div", { className: "contents_" }, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null)))));
    }
  });
})();
