(() => {
  // node_modules/clsx/dist/clsx.mjs
  function r(e) {
    var t, f, n = "";
    if ("string" == typeof e || "number" == typeof e) n += e;
    else if ("object" == typeof e) if (Array.isArray(e)) {
      var o = e.length;
      for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
    } else for (f in e) e[f] && (n && (n += " "), n += f);
    return n;
  }
  function clsx() {
    for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
    return n;
  }

  // ../blocks/picture/editor_script.tsx
  var { __ } = wp.i18n;
  var blockConfig = {
    devices: ["tb", "sp"],
    imageKeys: {
      image: { sources: "sources", src: "src", alt: "alt", code: "code" }
    }
  };
  CP.config.picture = blockConfig;
  wp.blocks.registerBlockType("catpow/picture", {
    icon: "id-alt",
    category: "catpow",
    example: CP.example,
    edit({ attributes, setAttributes, isSelected }) {
      const { InspectorControls, useBlockProps } = wp.blockEditor;
      const { Icon } = wp.components;
      const { isTemplate, classes, vars, sources, src, srcset, alt, code, device } = attributes;
      const states = CP.classNamesToFlags(classes);
      const { devices, imageKeys } = blockConfig;
      const selectiveClasses = [
        {
          input: "picture",
          label: __("\u753B\u50CF", "catpow"),
          keys: imageKeys?.image,
          devices,
          isTemplate
        },
        {
          label: __("\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8", "catpow"),
          input: "bool",
          key: "isTemplate",
          sub: [
            {
              input: "text",
              label: __("\u753B\u50CF\u30B3\u30FC\u30C9", "catpow"),
              key: "code",
              cond: true
            }
          ]
        }
      ];
      const blockProps = useBlockProps({
        className: clsx(classes, device, { "cp-altcontent": device }),
        style: vars
      });
      const panelProps = { attributes, setAttributes };
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectDeviceToolbar, { ...panelProps, devices }), /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.SelectResponsiveImage, { className: "_picture", ...panelProps, keys: imageKeys?.image, device, devices, isTemplate, showSelectPictureSources: isSelected }))), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30AF\u30E9\u30B9", "catpow"), icon: "art", ...panelProps, selectiveClasses })));
    },
    save({ attributes }) {
      const { useBlockProps } = wp.blockEditor;
      const { isTemplate, classes, vars, srouces, src, srcset, alt, code } = attributes;
      const states = CP.classNamesToFlags(classes);
      const { devices, imageKeys } = CP.config.picture;
      const blockProps = useBlockProps.save({
        className: classes,
        style: vars
      });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.ResponsiveImage, { className: "_picture", attributes, keys: imageKeys.image, devices, isTemplate }))));
    }
  });
})();
