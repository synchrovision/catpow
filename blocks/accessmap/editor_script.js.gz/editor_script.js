(() => {
  // ../blocks/accessmap/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/accessmap", {
    apiVersion: 3,
    title: "\u{1F43E} Access Map",
    description: "\u5730\u56F3\u3068\u30A2\u30AF\u30BB\u30B9\u60C5\u5831\u3092\u8868\u793A",
    icon: "location-alt",
    category: "catpow",
    example: CP.example,
    edit({ attributes, setAttributes, isSelected }) {
      const { useMemo } = wp.element;
      const { InnerBlocks, InspectorControls, RichText, useBlockProps } = wp.blockEditor;
      const { Icon, PanelBody, TextareaControl } = wp.components;
      const { classes, vars, HeadingTag, items = [], z, t, hl, loopCount, doLoop, EditMode = false, AltMode = false } = attributes;
      var states = useMemo(() => CP.classNamesToFlags(classes), [classes]);
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          "headingTag",
          "level",
          "color",
          "colorScheme",
          {
            name: "type",
            type: "buttons",
            label: "\u30BF\u30A4\u30D7",
            values: { isTypeFlat: "\u30D5\u30E9\u30C3\u30C8", isTypeCard: "\u30AB\u30FC\u30C9", isTypeFrame: "\u30D5\u30FC\u30EC\u30E0" }
          },
          "hasMargin",
          "hasPadding",
          "hasContentWidth",
          "itemSize",
          {
            name: "mapColor",
            type: "buttons",
            label: "\u5730\u56F3\u306E\u8272",
            values: {
              hasMapColorNone: "\u901A\u5E38",
              hasMapColorGray: "\u30B0\u30EC\u30FC",
              hasMapColorSync: "\u540C\u8272"
            }
          },
          { name: "hasTel", values: "hasTel", label: "\u96FB\u8A71\u756A\u53F7" },
          { name: "hasMail", values: "hasMail", label: "\u30E1\u30FC\u30EB" },
          { name: "hasSite", values: "hasSite", label: "\u30B5\u30A4\u30C8" },
          {
            name: "t",
            key: "t",
            input: "select",
            label: "\u5730\u56F3\u30BF\u30A4\u30D7",
            values: {
              m: "\u5730\u56F3",
              k: "\u822A\u7A7A\u5199\u771F",
              h: "\u5730\u56F3 + \u822A\u7A7A\u5199\u771F",
              p: "\u5730\u5F62\u56F3",
              e: "Google Earth"
            }
          },
          {
            name: "z",
            key: "z",
            input: "range",
            label: "\u30BA\u30FC\u30E0",
            min: 0,
            max: 23
          },
          {
            name: "hl",
            key: "hl",
            input: "buttons",
            label: "\u8A00\u8A9E",
            values: ["ja", "us", "zh-CN", "zh-TW"]
          },
          "isTemplate"
        ];
        wp.hooks.applyFilters("catpow.blocks.accessmap.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const selectiveItemClasses = useMemo(() => {
        const selectiveItemClasses2 = [
          "color",
          {
            name: "source",
            type: "gridbuttons",
            values: { useQuery: "\u691C\u7D22", useEmbedUrl: "\u57CB\u3081\u8FBC\u307FURL" },
            sub: {
              useQuery: [
                { name: "q", key: "q", input: "text", label: "\u691C\u7D22\u30EF\u30FC\u30C9" },
                { name: "ll", key: "ll", input: "text", label: "\u4E2D\u5FC3\u5EA7\u6A19" }
              ],
              useEmbedUrl: [
                {
                  name: "src",
                  key: "src",
                  input: "textarea",
                  label: "\u57CB\u3081\u8FBC\u307FURL",
                  rows: 10,
                  filter: (value, state, props) => {
                    const matches = value.match(/src="(.+?)"/);
                    if (matches) {
                      return matches[1];
                    }
                    return value;
                  }
                }
              ]
            }
          }
        ];
        wp.hooks.applyFilters("catpow.blocks.accessmap.selectiveItemClasses", CP.finderProxy(selectiveItemClasses2));
        return selectiveItemClasses2;
      }, []);
      const selectiveItemTemplateClasses = useMemo(() => {
        const selectiveItemTemplateClasses2 = [
          {
            name: "imageMapCode",
            input: "text",
            label: "\u5730\u56F3\u753B\u50CF\u30B3\u30FC\u30C9",
            key: "imageCode",
            cond: "hasImage"
          }
        ];
        wp.hooks.applyFilters("catpow.blocks.accessmap.selectiveItemTemplateClasses", CP.finderProxy(selectiveItemTemplateClasses2));
        return selectiveItemTemplateClasses2;
      }, []);
      const save = () => {
        setAttributes({ items: JSON.parse(JSON.stringify(items)) });
      };
      const blockProps = useBlockProps({ className: EditMode || AltMode && doLoop ? "cp-altcontent" : classes, style: vars });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.SelectModeToolbar, { setAttributes, attributes }), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u30AF\u30E9\u30B9", icon: "art", ...{ setAttributes, attributes }, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: "\u30AF\u30E9\u30B9", onChange: (classes2) => setAttributes({ classes: classes2 }), value: classes })), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: "\u30EA\u30B9\u30C8\u30A2\u30A4\u30C6\u30E0", icon: "edit", ...{ setAttributes, attributes }, itemKeys: ["items", attributes.currentItemIndex], selectiveClasses: selectiveItemClasses }), states.isTemplate && /* @__PURE__ */ wp.element.createElement(
        CP.SelectClassPanel,
        {
          title: "\u30C6\u30F3\u30D7\u30EC\u30FC\u30C8",
          icon: "edit",
          ...{ setAttributes, attributes },
          itemKeys: ["items", attributes.currentItemIndex],
          selectiveClasses: selectiveItemTemplateClasses
        }
      ), /* @__PURE__ */ wp.element.createElement(CP.ItemControlInfoPanel, null)), EditMode ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "welcome-comments" }, "\u30A2\u30AF\u30BB\u30B9\u60C5\u5831"), /* @__PURE__ */ wp.element.createElement(
        CP.EditItemsTable,
        {
          setAttributes,
          attributes,
          columns: [
            { type: "text", key: "q" },
            { type: "text", key: "ll" },
            { type: "text", key: "title" },
            { type: "text", key: "zipcode" },
            { type: "text", key: "address" },
            { type: "text", key: "tel" },
            { type: "text", key: "mail" },
            { type: "text", key: "site" },
            { type: "text", key: "info" }
          ],
          isTemplate: states.isTemplate
        }
      )) : /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, AltMode && doLoop ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "welcome-comments" }, "\u4EE3\u66FF\u30B3\u30F3\u30C6\u30F3\u30C4"), /* @__PURE__ */ wp.element.createElement(InnerBlocks, null)) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, [...Array(Math.max(items.length, loopCount)).keys()].map((i) => {
        let url;
        const index = i % items.length;
        const item = items[index];
        const itemState = CP.classNamesToFlags(item.classes);
        if (itemState.useEmbedURL) {
          url = item.src;
        } else {
          let q = item.q || item.address.replace(/<br\/?>|\n/, " ");
          url = `https://www.google.com/maps?output=embed&z=${z}&t=${t}&hl=${hl}&q=${q}`;
          if (!!item.ll) {
            url += `&ll=${item.ll}`;
          }
        }
        if (!item.controlClasses) {
          item.controlClasses = "control";
        }
        return /* @__PURE__ */ wp.element.createElement(CP.Item, { tag: "div", className: item.classes, ...{ setAttributes, attributes }, itemKeys: ["items", index], key: i }, /* @__PURE__ */ wp.element.createElement("div", { className: "_map" }, states.isTemplate ? /* @__PURE__ */ wp.element.createElement(CP.DummyImage, { className: "_gmap", text: item.q || item.address.replace(/<br\/?>|\n/, " ") }) : /* @__PURE__ */ wp.element.createElement("iframe", { src: url, className: "_gmap", "data-ll": item.ll || false, "data-q": item.q || false })), /* @__PURE__ */ wp.element.createElement("div", { className: "_access" }, /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: HeadingTag,
            className: "_title",
            onChange: (title) => {
              item.title = title;
              save();
            },
            value: item.title
          }
        ), /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "div",
            className: "_address",
            onChange: (address) => {
              item.address = address;
              save();
            },
            value: item.address
          }
        ), states.hasTel && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "div",
            className: "_tel",
            onChange: (tel) => {
              item.tel = tel;
              save();
            },
            value: item.tel
          }
        ), states.hasMail && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "div",
            className: "_mail",
            onChange: (mail) => {
              item.mail = mail;
              save();
            },
            value: item.mail
          }
        ), states.hasSite && /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "div",
            className: "_site",
            onChange: (site) => {
              item.site = site;
              save();
            },
            value: item.site
          }
        ), /* @__PURE__ */ wp.element.createElement(
          RichText,
          {
            tagName: "div",
            className: "_info",
            onChange: (info) => {
              item.info = info;
              save();
            },
            value: item.info
          }
        )));
      })))));
    },
    save({ attributes }) {
      const { InnerBlocks, RichText } = wp.blockEditor;
      const { classes, vars, HeadingTag, items = [], z, t, hl, doLoop } = attributes;
      const states = CP.classNamesToFlags(classes);
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("div", { className: classes, style: vars }, items.map((item, index) => {
        let url;
        const itemState = CP.classNamesToFlags(item.classes);
        if (itemState.useEmbedURL) {
          url = item.src;
        } else {
          let q = item.q || item.address.replace(/<br\/?>|\n/, " ");
          url = `https://www.google.com/maps?output=embed&z=${z}&t=${t}&hl=${hl}&q=${q}`;
          if (!!item.ll) {
            url += `&ll=${item.ll}`;
          }
        }
        return /* @__PURE__ */ wp.element.createElement("div", { className: item.classes, key: index }, /* @__PURE__ */ wp.element.createElement("div", { className: "_map" }, /* @__PURE__ */ wp.element.createElement("iframe", { src: url, className: "_gmap", "data-ll": item.ll, "data-q": item.q })), /* @__PURE__ */ wp.element.createElement("div", { className: "_access" }, /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: HeadingTag, className: "_title", value: item.title }), /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "div", className: "_address", value: item.address }), states.hasTel && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "div", className: "_tel", value: item.tel }), states.hasMail && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "div", className: "_mail", value: item.mail }), states.hasSite && /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "div", className: "_site", value: item.site }), /* @__PURE__ */ wp.element.createElement(RichText.Content, { tagName: "div", className: "_info", value: item.info })));
      }))), doLoop && /* @__PURE__ */ wp.element.createElement("on-empty", null, /* @__PURE__ */ wp.element.createElement(InnerBlocks.Content, null)));
    }
  });
})();
