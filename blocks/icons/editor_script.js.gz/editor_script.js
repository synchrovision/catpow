(() => {
  // ../blocks/icons/editor_script.jsx
  var { __ } = wp.i18n;
  wp.blocks.registerBlockType("catpow/icons", {
    icon: "image-filter",
    category: "catpow",
    transforms: {
      from: [
        {
          type: "block",
          blocks: CP.listedConvertibles,
          transform: (attributes) => {
            attributes.classes = "wp-block-catpow-icons medium hasSubTitle hasText";
            return wp.blocks.createBlock("catpow/icons", attributes);
          }
        }
      ]
    },
    example: CP.example,
    edit({ attributes, className, setAttributes, isSelected }) {
      const { useMemo } = wp.element;
      const { BlockControls, InspectorControls, useBlockProps } = wp.blockEditor;
      const { PanelBody, TextareaControl, ToolbarGroup } = wp.components;
      const { items = [], classes, vars, EditMode = false } = attributes;
      const selectiveClasses = useMemo(() => {
        const selectiveClasses2 = [
          { name: "size", type: "buttons", label: __("\u30B5\u30A4\u30BA", "catpow"), values: { isSizeSmall: __("\u5C0F", "catpow"), isSizeMedium: __("\u4E2D", "catpow"), isSizeLarge: __("\u5927", "catpow") } },
          { name: "filled", label: __("\u5857\u308A", "catpow"), values: "isFilled", sub: [{ name: "shape", type: "buttons", label: __("\u5F62\u72B6", "catpow"), values: { isShapeCircle: __("\u4E38", "catpow"), isShapeSquare: __("\u56DB\u89D2", "catpow") } }] }
        ];
        wp.hooks.applyFilters("catpow.blocks.icons.selectiveClasses", CP.finderProxy(selectiveClasses2));
        return selectiveClasses2;
      }, []);
      const selectiveItemClasses = useMemo(() => {
        const selectiveItemClasses2 = [
          { name: "image", input: "image", keys: { src: "src", alt: "alt", items: "items" }, size: "thumbnail" },
          { name: "link", input: "text", key: "href", label: __("\u30EA\u30F3\u30AF", "catpow") },
          "color"
        ];
        wp.hooks.applyFilters("catpow.blocks.icons.selectiveItemClasses", CP.finderProxy(selectiveItemClasses2));
        return selectiveItemClasses2;
      }, []);
      const blockProps = useBlockProps({ className: EditMode ? "cp-altcontent" : classes, style: vars });
      return /* @__PURE__ */ wp.element.createElement(wp.element.Fragment, null, /* @__PURE__ */ wp.element.createElement(BlockControls, null, /* @__PURE__ */ wp.element.createElement(
        ToolbarGroup,
        {
          controls: [
            {
              icon: "edit",
              title: "EditMode",
              isActive: attributes.EditMode,
              onClick: () => setAttributes({ EditMode: !EditMode })
            }
          ]
        }
      ), /* @__PURE__ */ wp.element.createElement(CP.AlignClassToolbar, { setAttributes, attributes })), /* @__PURE__ */ wp.element.createElement(InspectorControls, null, /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30AF\u30E9\u30B9", "catpow"), icon: "art", ...{ setAttributes, attributes }, selectiveClasses }), /* @__PURE__ */ wp.element.createElement(PanelBody, { title: "CLASS", icon: "admin-generic", initialOpen: false }, /* @__PURE__ */ wp.element.createElement(TextareaControl, { label: __("\u30AF\u30E9\u30B9", "catpow"), onChange: (classes2) => setAttributes({ classes: classes2 }), value: classes })), /* @__PURE__ */ wp.element.createElement(CP.SelectClassPanel, { title: __("\u30A2\u30A4\u30C6\u30E0", "catpow"), icon: "edit", ...{ setAttributes, attributes }, itemKeys: ["items", attributes.currentItemIndex], selectiveClasses: selectiveItemClasses }), /* @__PURE__ */ wp.element.createElement(CP.ItemControlInfoPanel, null)), EditMode ? /* @__PURE__ */ wp.element.createElement("div", { ...blockProps }, /* @__PURE__ */ wp.element.createElement(CP.Label, { icon: "edit" }), /* @__PURE__ */ wp.element.createElement(
        CP.EditItemsTable,
        {
          setAttributes,
          attributes,
          columns: [
            { type: "image", key: "src" },
            { type: "text", key: "alt" },
            { type: "text", key: "href" }
          ]
        }
      )) : /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { ...blockProps }, items.map((item, index) => {
        if (!item.controlClasses) {
          item.controlClasses = "control";
        }
        return /* @__PURE__ */ wp.element.createElement(CP.Item, { tag: "li", className: item.classes, ...{ setAttributes, attributes }, itemKeys: ["items", index], key: index }, /* @__PURE__ */ wp.element.createElement("a", { className: "_link" }, /* @__PURE__ */ wp.element.createElement("img", { className: "_icon", src: item.src, alt: item.alt })));
      }))));
    },
    save({ attributes, className }) {
      const { useBlockProps } = wp.blockEditor;
      const { items = [], classes, vars } = attributes;
      return /* @__PURE__ */ wp.element.createElement(CP.Bem, { prefix: "wp-block-catpow" }, /* @__PURE__ */ wp.element.createElement("ul", { ...useBlockProps.save({ className: classes, style: vars }) }, items.map((item, index) => /* @__PURE__ */ wp.element.createElement("li", { className: item.classes, key: index }, /* @__PURE__ */ wp.element.createElement("a", { className: "_link", href: item.href }, /* @__PURE__ */ wp.element.createElement("img", { className: "_icon", src: item.src, alt: item.alt }))))));
    }
  });
})();
